package com.project_4.cookpad_api.api.client;

import com.project_4.cookpad_api.entity.Favourite;
import com.project_4.cookpad_api.entity.Product;
import com.project_4.cookpad_api.entity.User;
import com.project_4.cookpad_api.search.SearchBody;
import com.project_4.cookpad_api.service.FavouriteService;
import com.project_4.cookpad_api.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(path = "api/v1/user/favourite")
@RequiredArgsConstructor
@CrossOrigin("*")
public class FavouriteListApi {

    @Autowired
    FavouriteService favouriteService;

    @Autowired
    UserService userService;

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<?> favouriteList(Principal principal,
           @RequestParam(name = "page", defaultValue = "1") int page,
           @RequestParam(name = "limit", defaultValue = "10") int limit,
           @RequestParam(name = "nameProduct", required = false) String nameProduct,
           @RequestParam(name = "startPrice", required = false) String startPrice,
           @RequestParam(name = "endPrice", required = false) String endPrice,
           @RequestParam(name = "sort", required = false) String sort,
           @RequestParam(name = "sortPrice", required = false) String sortPrice){
        SearchBody searchBody = SearchBody.SearchBodyBuilder.aSearchBody()
                .withPage(page)
                .withLimit(limit)
                .withNameProduct(nameProduct)
                .withStartPrice(startPrice)
                .withEndPrice(endPrice)
                .withSort(sort)
                .withSortPrice(sortPrice)
                .build();
//        Optional<User> optionalUser = userService.findByNameActive(principal.getName());
//        if (!optionalUser.isPresent()){
//            ResponseEntity.badRequest().build();
//        }
//        List<Product> products = favouriteService.findAll(searchBody, optionalUser.get());
        return ResponseEntity.ok(favouriteService.findAll(searchBody));
    }

    @RequestMapping(method = RequestMethod.POST, path = "/{productId}")
    public ResponseEntity<?> favourite(Principal principal, @PathVariable Long productId){
        Optional<User> optionalUser = userService.findByNameActive(principal.getName());
        if (!optionalUser.isPresent()){
            ResponseEntity.badRequest().build();
        }
        Favourite favourite = favouriteService.FavouriteList(optionalUser.get(), productId);
        return ResponseEntity.ok(favourite);
    }
}
