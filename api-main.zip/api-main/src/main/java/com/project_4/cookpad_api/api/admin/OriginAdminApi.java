package com.project_4.cookpad_api.api.admin;

import com.project_4.cookpad_api.entity.Category;
import com.project_4.cookpad_api.entity.Origin;
import com.project_4.cookpad_api.service.OriginService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(path = "api/v1/admin/origins")
@RequiredArgsConstructor
@CrossOrigin("*")
public class OriginAdminApi {
    @Autowired
    OriginService originService;

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<Origin>> findAll(){
        return ResponseEntity.ok(originService.findAll());
    }
}
