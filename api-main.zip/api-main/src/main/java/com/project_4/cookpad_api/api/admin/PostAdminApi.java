package com.project_4.cookpad_api.api.admin;

import com.project_4.cookpad_api.entity.Post;
import com.project_4.cookpad_api.entity.myenum.Status;
import com.project_4.cookpad_api.search.SearchBody;
import com.project_4.cookpad_api.service.OriginService;
import com.project_4.cookpad_api.service.PostCategoryService;
import com.project_4.cookpad_api.service.PostService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping(path = "api/v1/admin/post")
@RequiredArgsConstructor
@CrossOrigin("*")
public class PostAdminApi {

    @Autowired
    OriginService originService;
    @Autowired
    PostCategoryService postCategoryService;
    @Autowired
    PostService postService;

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<?> findAll(
            @RequestParam(name = "page", defaultValue = "1") int page,
            @RequestParam(name = "limit", defaultValue = "10") int limit,
            @RequestParam(name = "sort", required = false) String sort,
            @RequestParam(name = "start", required = false) String start,
            @RequestParam(name = "status", defaultValue = "-1") int status,
            @RequestParam(name = "cateId", defaultValue = "-1") Long cateId,
            @RequestParam(name = "originId", defaultValue = "-1") Long originId,
            @RequestParam(name = "userPostId", defaultValue = "-1") Long userPostId,
            @RequestParam(name = "end", required = false) String end,
            @RequestParam(name = "name", required = false) String name,
            @RequestParam(name = "username", required = false) String username
    ) {
        SearchBody searchBody = SearchBody.SearchBodyBuilder.aSearchBody()
                .withPage(page)
                .withLimit(limit)
                .withSort(sort)
                .withCateId(cateId)
                .withStatus(status)
                .withOriginId(originId)
                .withUserPostId(userPostId)
                .withStart(start)
                .withEnd(end)
                .withUsername(username)
                .withNameProduct(name)
                .build();

        return ResponseEntity.ok(postService.findAll(searchBody));
    }

    @RequestMapping(method = RequestMethod.GET, path = "/total")
    public int total(){
        return postService.total();
    }

    @RequestMapping(method = RequestMethod.GET, path = "/totalByStatus/{status}")
    public int totalByStatus(@PathVariable int status){
        return postService.totalByStatus(status);
    }

    @RequestMapping(method = RequestMethod.PUT, path = "/{id}")
    public Post update(@PathVariable Long id, @RequestParam(name = "status") int status){
        Status status1 = null;
        if (status == 1){
            status1 = Status.ACTIVE;
        }
        if (status == 5){
            status1 = Status.LOCKED;
        }
        Optional<Post> post = postService.findById(id);
        post.get().setStatus(status1);
        return postService.save(post.get());
    }

    @RequestMapping(method = RequestMethod.GET, path = "/{id}")
    public ResponseEntity<?> findById(@PathVariable Long id){
        return ResponseEntity.ok(postService.findById(id));
    }
}
