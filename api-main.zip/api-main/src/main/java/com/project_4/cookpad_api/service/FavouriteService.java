package com.project_4.cookpad_api.service;

import com.project_4.cookpad_api.entity.Favourite;
import com.project_4.cookpad_api.entity.Product;
import com.project_4.cookpad_api.entity.User;
import com.project_4.cookpad_api.entity.myenum.Status;
import com.project_4.cookpad_api.repository.FavouriteRepository;
import com.project_4.cookpad_api.repository.ProductRepository;
import com.project_4.cookpad_api.repository.UserRepository;
import com.project_4.cookpad_api.search.FavoriteSpecification;
import com.project_4.cookpad_api.search.ProductSpecification;
import com.project_4.cookpad_api.search.SearchBody;
import com.project_4.cookpad_api.search.SearchCriteria;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.util.*;

import static com.project_4.cookpad_api.search.SearchCriteriaOperator.*;
import static com.project_4.cookpad_api.search.SearchCriteriaOperator.LESS_THAN_OR_EQUALS;

@Service
@Transactional
@RequiredArgsConstructor
public class FavouriteService {

    @Autowired
    FavouriteRepository favouriteRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    ProductRepository productRepository;

    public Favourite FavouriteList(User user, Long productId){
        Optional<Product> optionalProduct = productRepository.findByIdAndStatus(productId, Status.ACTIVE);
        if (!optionalProduct.isPresent()){
            return null;
        }
        Optional<Favourite> optionalFavourite = favouriteRepository.findByUserId(user.getId());
        if (optionalFavourite.isPresent()){
            Set<Product> products = optionalFavourite.get().getProducts();
            boolean exits = false;
            for (Product product:products
            ) {
                if (product.getId().equals(productId)){
                    exits = true;
                    products.remove(product);
                }
            }
            if (!exits){
                products.add(optionalProduct.get());
            }
            return favouriteRepository.save(optionalFavourite.get());
        }else {
            Favourite favourite = new Favourite();
            favourite.setUserId(user.getId());
            Set<Product> products = new HashSet<>();
            products.add(optionalProduct.get());
            favourite.setProducts(products);
            return favouriteRepository.save(favourite);
        }
    }

    //    public List<Product> findAll(SearchBody searchBody, User user){
//        Optional<Favourite> optionalFavourite = favouriteRepository.findByUserId(user.getId());
//        Set<Product> products = optionalFavourite.get().getProducts();
//        return new ArrayList<>(products);
//    }
    public Map<String, Object> findAll(SearchBody searchBody){
        Specification specification = Specification.where(null);

        if (searchBody.getNameProduct() != null && searchBody.getNameProduct().length() > 0 ){
            specification = specification.and(new FavoriteSpecification(new SearchCriteria("name", JOIN, "%" + searchBody.getNameProduct() + "%")));
        }
//        if (searchBody.getStartPrice() != null && searchBody.getStartPrice().length() > 0){
//            BigDecimal startPrice = new BigDecimal(searchBody.getStartPrice());
//            specification = specification.and(new FavoriteSpecification(new SearchCriteria("price", GREATER_THAN_OR_EQUALS,startPrice)));
//        }
//        if (searchBody.getEndPrice() != null && searchBody.getEndPrice().length() > 0){
//            BigDecimal endPrice = new BigDecimal(searchBody.getEndPrice());
//            specification = specification.and(new FavoriteSpecification(new SearchCriteria("price", LESS_THAN_OR_EQUALS,endPrice)));
//        }

//        Sort sortPrice = Sort.by(Sort.Order.asc("price"));
//        if (searchBody.getSortPrice() !=null && searchBody.getSortPrice().length() >0){
//            if (searchBody.getSortPrice().contains("desc")){
//                sortPrice = Sort.by(Sort.Order.desc("price"));
//            }
//        }

//        Sort sortId = Sort.by(Sort.Order.asc("id"));
//        if (searchBody.getSort() !=null && searchBody.getSort().length() >0){
//            if (searchBody.getSort().contains("desc")){
//                sortId = Sort.by(Sort.Order.desc("id"));
//            }
//        }
//
//        Sort sort = sortPrice.and(sortId);

//        Pageable pageable = PageRequest.of(searchBody.getPage() -1, searchBody.getLimit(),sort );
        Pageable pageable = PageRequest.of(searchBody.getPage() -1, searchBody.getLimit() );
        Page<Product> productPage = favouriteRepository.findAll(specification,pageable);
        List<Product> orderList = productPage.getContent();
        Map<String, Object> responses = new HashMap<>();
        responses.put("content",orderList);
        responses.put("currentPage",productPage.getNumber() + 1);
        responses.put("totalItems",productPage.getTotalElements());
        responses.put("totalPage",productPage.getTotalPages());
        return responses;
    }

}
