package com.project_4.cookpad_api.repository;

import com.project_4.cookpad_api.entity.Making;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MakingRepository extends JpaRepository<Making, Integer> {
}
