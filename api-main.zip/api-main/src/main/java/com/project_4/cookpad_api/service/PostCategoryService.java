package com.project_4.cookpad_api.service;

import com.project_4.cookpad_api.entity.PostCategory;
import com.project_4.cookpad_api.repository.PostCategoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
@RequiredArgsConstructor
public class PostCategoryService {
    @Autowired
    PostCategoryRepository postCategoryRepository;

    public Optional<PostCategory> findByName(String name){
        return postCategoryRepository.findByName(name);
    }

    public List<PostCategory> findAll(){
        return postCategoryRepository.findAll();
    }
}
