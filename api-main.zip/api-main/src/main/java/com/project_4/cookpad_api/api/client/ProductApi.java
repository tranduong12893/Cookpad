package com.project_4.cookpad_api.api.client;

import com.project_4.cookpad_api.entity.Favourite;
import com.project_4.cookpad_api.entity.Product;
import com.project_4.cookpad_api.entity.User;
import com.project_4.cookpad_api.entity.myenum.Status;
import com.project_4.cookpad_api.search.SearchBody;
import com.project_4.cookpad_api.service.FavouriteService;
import com.project_4.cookpad_api.service.ProductService;
import com.project_4.cookpad_api.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.Optional;

@RestController
@RequestMapping(path = "api/v1/user/products")
@RequiredArgsConstructor
@CrossOrigin("*")
public class ProductApi {
//asdadsa
    @Autowired
    ProductService productService;

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<?> findAll(
            @RequestParam(name = "page", defaultValue = "1") int page,
            @RequestParam(name = "limit", defaultValue = "10") int limit,
            @RequestParam(name = "name", required = false) String name,
            @RequestParam(name = "startPrice", required = false) String startPrice,
            @RequestParam(name = "endPrice", required = false) String endPrice,
            @RequestParam(name = "sort", required = false) String sort,
            @RequestParam(name = "sortPrice", required = false) String sortPrice,
            @RequestParam(name = "cateId", defaultValue = "-1") Long cateId,
            @RequestParam(name = "status", defaultValue = "1") int status
    ){
        SearchBody searchBody = SearchBody.SearchBodyBuilder.aSearchBody()
                .withPage(page)
                .withLimit(limit)
                .withNameProduct(name)
                .withStartPrice(startPrice)
                .withEndPrice(endPrice)
                .withCateId(cateId)
                .withSort(sort)
                .withStatus(status)
                .withSortPrice(sortPrice)
                .build();
        return ResponseEntity.ok(productService.findAll(searchBody));
    }

    @RequestMapping(method = RequestMethod.GET, path = "/{id}")
    public ResponseEntity<Product> findById(@PathVariable Long id){
        Optional<Product> optionalProduct = productService.findByIdActive(id);
        if (!optionalProduct.isPresent()){
            ResponseEntity.badRequest().build();
        }
        return ResponseEntity.ok(optionalProduct.get());
    }
}
