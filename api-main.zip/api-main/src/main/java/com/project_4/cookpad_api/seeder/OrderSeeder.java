package com.project_4.cookpad_api.seeder;

import com.github.javafaker.Faker;
import com.project_4.cookpad_api.entity.*;
import com.project_4.cookpad_api.entity.myenum.OrderStatus;
import com.project_4.cookpad_api.repository.OrderDetailRepository;
import com.project_4.cookpad_api.repository.OrderRepository;
import com.project_4.cookpad_api.util.DateTimeHelper;
import com.project_4.cookpad_api.util.NumberUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.Month;
import java.util.*;

@Component
public class OrderSeeder {
    @Autowired
    OrderDetailRepository orderDetailRepository;

    Faker faker = new Faker();

    public static List<Order> orders;
    public static final int NUMBER_OF_ORDER = 1000;
    public static final int NUMBER_OF_DONE = 600;
    public static final int NUMBER_OF_CANCEL = 200;
    public static final int NUMBER_OF_PENDING = 200;
    public static final int MIN_ORDER_DETAIL = 2;
    public static final int MAX_ORDER_DETAIL = 3;
    public static final int MIN_PRODUCT_QUANTITY = 1;
    public static final int MAX_PRODUCT_QUANTITY = 5;

    @Autowired
    OrderRepository orderRepository;
    List<OrderSeedByTime> seeder;

    public void configData() {
        seeder = new ArrayList<>();
        int year = 2022;
        boolean isDate = false;
        LocalDateTime now = LocalDateTime.now();
        for (int j = 1; j < 13; j++){
            Month month = null;
            int day = 0;
            if (j == 4 || j == 6 || j == 9 || j == 11){
                day = 31;
            } else if (j == 2) {
//                boolean isLeap = false;
//                if(year % 4 == 0)//chia hết cho 4 là năm nhuận
//                {
//                    if( year % 100 == 0)
//                    //nếu vừa chia hết cho 4 mà vừa chia hết cho 100 thì không phải năm nhuận
//                    {
//                        if ( year % 400 == 0)//chia hết cho 400 là năm nhuận
//                            isLeap = true;
//                        else
//                            isLeap = false;//không chia hết cho 400 thì không phải năm nhuận
//                    }
//                    else//chia hết cho 4 nhưng không chia hết cho 100 là năm nhuận
//                        isLeap = true;
//                }
//                else {
//                    isLeap = false;
//                }
//                if (isLeap){
//                    day = 30;
//                } else if (!isLeap) {
//                    day = 29;
//                }
                day = 29;
            }else {
                day = 32;
            }
            if (j == 1){
                month = Month.JANUARY;
            }
            if (j == 2){
                month = Month.FEBRUARY;
            }
            if (j == 3){
                month = Month.MARCH;
            }
            if (j == 4){
                month = Month.APRIL;
            }
            if (j == 5){
                month = Month.MAY;
            }
            if (j == 6){
                month = Month.JUNE;
            }
            if (j == 7){
                month = Month.JULY;
            }
            if (j == 8){
                month = Month.AUGUST;
            }
            if (j == 9){
                month = Month.SEPTEMBER;
            }
            if (j == 10){
                month = Month.OCTOBER;
            }
            if (j == 11){
                month = Month.NOVEMBER;
            }
            if (j == 12){
                month = Month.DECEMBER;
            }
            for (int l = 1; l < day; l++){
                if (month == now.getMonth() && l > now.getDayOfMonth()){
                    return;
                }
                int randomNumber = faker.number().numberBetween(4, 8);
                for (int k = 0; k < 4; k++){
                    OrderStatus orderStatus = null;
                    if (k == 0){
                        orderStatus = OrderStatus.PENDING;
                    }
                    if (k == 1){
                        orderStatus = OrderStatus.CONFIRMED;
                        randomNumber += 1;
                    }
                    if (k == 2){
                        orderStatus = OrderStatus.CANCELLED;
                        randomNumber -= 4;
                    }
                    if (k == 3){
                        orderStatus = OrderStatus.DONE;
                        randomNumber += 2;
                    }
                    seeder.add(
                            OrderSeedByTime.builder()
                                    .orderStatus(orderStatus).seedTypeByTime(OrderSeedByTimeType.DAY).day(l).month(month).year(year).orderCount(randomNumber)
                                    .build());
                }
            }
            if (month == now.getMonth()){
                return;
            }
        }
//        for (int i = 0; i < 3; i++){
//            year++;
//
//        }
    }

    public void generate() {
        configData();
        Faker faker = new Faker();
        orders = new ArrayList<>();
        for (OrderSeedByTime orderSeedByTime :
                seeder) {
            int numberOfOrder = orderSeedByTime.getOrderCount();
            for (int i = 0; i < numberOfOrder; i++) {
                // lấy random user.
                int randomUserIndex = NumberUtil.getRandomNumber(0, UserSeeder.userList.size() - 1);
                User user = UserSeeder.userList.get(randomUserIndex);
                // Tạo mới đơn hàng.
                Order order = new Order();
                order.setStatus(orderSeedByTime.getOrderStatus());
                LocalDateTime orderCreatedTime = calculateOrderCreatedTime(orderSeedByTime);
                order.setCreatedAt(orderCreatedTime);
                order.setUpdatedAt(orderCreatedTime);
                order.setUser(user);
                order.setName(faker.name().fullName());
                order.setAddress(faker.address().fullAddress());
                // Tạo danh sách order detail cho đơn hàng.
                Set<OrderDetail> orderDetails = new HashSet<>();
                // map này dùng để check sự tồn tại của sản phẩm trong order detail.
                HashMap<Long, Product> mapProduct = new HashMap<>();
                // generate số lượng của order detail.
                int orderDetailNumber = NumberUtil.getRandomNumber(MIN_ORDER_DETAIL, MAX_ORDER_DETAIL);
                for (int j = 0; j < orderDetailNumber; j++) {
                    // lấy random product.
                    int randomProductIndex = NumberUtil.getRandomNumber(0, ProductSeeder.productList.size() - 1);
                    Product product = ProductSeeder.productList.get(randomProductIndex);
                    // check tồn tại
                    if (mapProduct.containsKey(product.getId())) {
                        continue; // bỏ qua hoặc cộng dồn
                    }
                    // tạo order detail theo sản phẩm random
                    OrderDetail orderDetail = new OrderDetail();
                    orderDetail.setId(new OrderDetailId(order.getId(), product.getId()));
                    orderDetail.setOrder(order); // set quan hệ
                    orderDetail.setProduct(product); // set quan hệ
                    orderDetail.setUnitPrice(product.getPrice()); // giá theo sản phẩm
                    // random số lượng theo cấu hình
                    orderDetail.setQuantity(NumberUtil.getRandomNumber(MIN_PRODUCT_QUANTITY, MAX_PRODUCT_QUANTITY));
                    // đưa vào danh sách order detail
                    orderDetails.add(orderDetail);
                    mapProduct.put(product.getId(), product);
                }
                // set quan hệ với order
                order.setOrderDetails(orderDetails);
                order.calculateTotalPrice();
                order.setShoppingCart(faker.bool().bool());
                orders.add(order);
            }
        }
        orderRepository.saveAll(orders);
    }

    public void generateOrderDetail() {
        for (Order order :
                orders) {
            orderDetailRepository.saveAll(order.getOrderDetails());
        }
    }

    private LocalDateTime calculateOrderCreatedTime(OrderSeedByTime orderSeedByTime) {
        LocalDateTime result = null;
        LocalDateTime tempLocalDateTime = null;
        int tempMonth = 1;
        int tempYear = 2022;
        switch (orderSeedByTime.getSeedTypeByTime()) {
            case YEAR:
                // nếu theo năm thì random tháng và ngày.
                tempMonth = DateTimeHelper.getRandomMonth().getValue();
                tempYear = orderSeedByTime.getYear();
                tempLocalDateTime = LocalDateTime.of(tempYear, tempMonth, 1, 0, 0, 0);
                result = tempLocalDateTime.plusMonths(1).minusDays(1);
                break;
            case MONTH:
                // nếu theo tháng, năm thì random ngày.
                tempMonth = orderSeedByTime.getMonth().getValue();
                tempYear = orderSeedByTime.getYear();
                tempLocalDateTime = LocalDateTime.of(tempYear, tempMonth, 1, 0, 0, 0);
                LocalDateTime lastDayOfMonth = tempLocalDateTime.plusMonths(1).minusDays(1);
                int randomDay = NumberUtil.getRandomNumber(1, lastDayOfMonth.getDayOfMonth());
                result = LocalDateTime.of(tempYear, tempMonth, randomDay, 0, 0, 0);
                if (result.isAfter(LocalDateTime.now())) {
                    // nếu sau thời gian hiện tại, tức là tháng năm đang thời gian hiện tại
                    randomDay = NumberUtil.getRandomNumber(1, LocalDateTime.now().getDayOfMonth());
                    result = LocalDateTime.of(tempYear, tempMonth, randomDay, 0, 0, 0);
                }
                break;
            case DAY:
                // nếu là ngày thì fix
                result = LocalDateTime.of(orderSeedByTime.getYear(), orderSeedByTime.getMonth(), orderSeedByTime.getDay(), 0, 0, 0);
                break;
        }
        return result;
    }
}
