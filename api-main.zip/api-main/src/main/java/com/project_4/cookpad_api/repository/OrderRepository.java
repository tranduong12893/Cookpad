package com.project_4.cookpad_api.repository;

import com.project_4.cookpad_api.entity.Order;
import com.project_4.cookpad_api.entity.ShoppingCart;
import com.project_4.cookpad_api.entity.event.OrderEvent;
import com.project_4.cookpad_api.entity.myenum.OrderStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long>, JpaSpecificationExecutor<Order> {
    Page<Order> findAllBy(Pageable pageable);
    Order findByOrderDetails(OrderEvent orderEvent);
    @Query("SELECT max(o.id) FROM Order o")
    Long findMaxId();

    List<Order> findAllByStatus(OrderStatus status);

    List<Order> findAllByStatusAndCreatedAtBetween(OrderStatus status, LocalDateTime start, LocalDateTime end);
}
