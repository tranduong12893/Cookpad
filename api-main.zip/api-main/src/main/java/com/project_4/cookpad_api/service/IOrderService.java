package com.project_4.cookpad_api.service;

import com.project_4.cookpad_api.entity.Order;
import com.project_4.cookpad_api.entity.event.OrderEvent;
import org.springframework.stereotype.Repository;

@Repository
public interface IOrderService {
    Order placeOrder(Long id);
}
