package com.project_4.cookpad_api.service;

import com.project_4.cookpad_api.entity.*;
import com.project_4.cookpad_api.entity.dto.OrderDetailDto;
import com.project_4.cookpad_api.entity.event.OrderEvent;
import com.project_4.cookpad_api.entity.myenum.OrderStatus;
import com.project_4.cookpad_api.entity.myenum.Status;
import com.project_4.cookpad_api.repository.CartItemRepository;
import com.project_4.cookpad_api.repository.OrderDetailRepository;
import com.project_4.cookpad_api.repository.OrderRepository;
import com.project_4.cookpad_api.repository.ShoppingCartRepository;
import com.project_4.cookpad_api.search.OrderSearchBody;
import com.project_4.cookpad_api.search.OrderSpecification;
import com.project_4.cookpad_api.search.SearchCriteria;
import com.project_4.cookpad_api.util.DateTimeHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

import static com.project_4.cookpad_api.search.SearchCriteriaOperator.*;


@Service
public class OrderService implements IOrderService{
    @Autowired
    OrderRepository orderRepository;

    @Autowired
    OrderDetailRepository orderDetailRepository;

    @Autowired
    ShoppingCartRepository shoppingCartRepository;

    @Autowired
    ShoppingCartService shoppingCartService;

    @Autowired
    CartItemRepository cartItemRepository;

    public Optional<?> findById(Long id) {
        return orderRepository.findById(id);
    }

    public Order save(Order order) {
        return orderRepository.save(order);
    }

    public void delete(Long id) {
        orderRepository.deleteById(id);
    }
    public Order saveCart(Order order) {
        return orderRepository.save(order);
    }

    public Map<String, Object> findAll(Pageable pageable) {
        Map<String, Object> responses = new HashMap<>();
        Page<Order> pageTotal = orderRepository.findAllBy(pageable);
        List<Order> list = pageTotal.getContent();
        responses.put("content", list);
        responses.put("currentPage", pageTotal.getNumber() + 1);
        responses.put("totalItems", pageTotal.getTotalElements());
        responses.put("totalPage", pageTotal.getTotalPages());
        return responses;
    }

    public Map<String, Object> findOrdersBy(OrderSearchBody orderSearchBody) {
        Specification specification = Specification.where(null);

        if (orderSearchBody.getOrderId() != null && orderSearchBody.getOrderId().length() > 0) {
            specification = specification.and(new OrderSpecification(new SearchCriteria("id", EQUALS, orderSearchBody.getOrderId())));
        }
        if (orderSearchBody.getProductId() != null && orderSearchBody.getProductId().length() > 0) {
            specification = specification.and(new OrderSpecification(new SearchCriteria("id", EQUALS, orderSearchBody.getProductId())));
        }
        if (orderSearchBody.getNameProduct() != null && orderSearchBody.getNameProduct().length() > 0) {
            specification = specification.and(new OrderSpecification(new SearchCriteria("name", JOIN_DETAIL_PRODUCT, orderSearchBody.getNameProduct())));
        }
        if (orderSearchBody.getNameUser() != null && orderSearchBody.getNameUser().length() > 0) {
            specification = specification.and(new OrderSpecification(new SearchCriteria("username", JOIN_USER, orderSearchBody.getNameUser())));
        }
        if (orderSearchBody.getPhone() != null && orderSearchBody.getPhone().length() > 0) {
            specification = specification.and(new OrderSpecification(new SearchCriteria("phone", JOIN_USER, orderSearchBody.getPhone())));
        }
        if (orderSearchBody.getEmail() != null && orderSearchBody.getEmail().length() > 0) {
            specification = specification.and(new OrderSpecification(new SearchCriteria("email", JOIN_USER, orderSearchBody.getEmail())));
        }
        if (orderSearchBody.getStatus() > -1) {
            specification = specification.and(new OrderSpecification(new SearchCriteria("status", EQUALS, orderSearchBody.getStatus())));
        }
        if (orderSearchBody.getStart() != null && orderSearchBody.getStart().length() > 0){
            LocalDateTime date = DateTimeHelper.convertStringToLocalDateTime(orderSearchBody.getStart());
            specification = specification.and(new OrderSpecification(new SearchCriteria("createdAt", GREATER_THAN_OR_EQUALS,date)));
        }
        if (orderSearchBody.getEnd() != null && orderSearchBody.getEnd().length() > 0){
            LocalDateTime date = DateTimeHelper.convertStringToLocalDateTime(orderSearchBody.getEnd());
            specification = specification.and(new OrderSpecification(new SearchCriteria("createdAt", LESS_THAN_OR_EQUALS,date)));
        }

        Sort sortPrice = Sort.by(Sort.Order.asc("price"));
        if (orderSearchBody.getSortPrice() !=null && orderSearchBody.getSortPrice().length() >0){
            if (orderSearchBody.getSortPrice().contains("desc")){
                sortPrice = Sort.by(Sort.Order.desc("price"));
            }
        }

        Sort sortId = Sort.by(Sort.Order.asc("createdAt"));
        if (orderSearchBody.getSort() !=null && orderSearchBody.getSort().length() >0){
            if (orderSearchBody.getSort().contains("desc")){
                sortId = Sort.by(Sort.Order.desc("createdAt"));
            }
        }

        Sort sort = sortPrice.and(sortId);

        if (orderSearchBody.getSortPrice().length()<=0){
            sort = sortId;
        }

        Pageable pageable = PageRequest.of(orderSearchBody.getPage() -1, orderSearchBody.getLimit(), sort);
        Page<Order> pageOrder = orderRepository.findAll(specification,pageable);
        List<Order> orderList = pageOrder.getContent();
        Map<String, Object> responses = new HashMap<>();
        responses.put("content",orderList);
        responses.put("currentPage",pageOrder.getNumber() + 1);
        responses.put("totalItems",pageOrder.getTotalElements());
        responses.put("totalPage",pageOrder.getTotalPages());
        return responses;
    }

    @Override
    @Transactional
    public Order placeOrder(Long id) {
        Optional<ShoppingCart> shoppingCartOptional = shoppingCartRepository.findById(id);
        if (shoppingCartOptional.isPresent()) {
            ShoppingCart shoppingCart = shoppingCartOptional.get();
            Set<OrderDetail> orderDetailSet = new HashSet<>();
            OrderDetail dto = null;
            for (CartItem cartItem:
                    shoppingCart.getItems()) {
                dto = new OrderDetail();
                dto.setId(new OrderDetailId(orderRepository.findMaxId() + 1, cartItem.getProduct().getId()));
                dto.setOrder(Order.builder().id(orderRepository.findMaxId() + 1).build());
                dto.setProduct(cartItem.getProduct());
                dto.setQuantity(cartItem.getQuantity());
                dto.setUnitPrice(cartItem.getProduct().getPrice());
                dto.setQuantity(cartItem.getQuantity());
                orderDetailSet.add(dto);
            }
            Order order = Order.builder()
                    .status(OrderStatus.PROCESSING)
                    .user(shoppingCart.getUser())
                    .orderDetails(orderDetailSet)
                    .totalPrice(shoppingCart.getItems().stream().map(cartItem -> cartItem.getProduct().getPrice().multiply(BigDecimal.valueOf(cartItem.getQuantity()))).reduce(BigDecimal.ZERO, BigDecimal::add))
                    .name(shoppingCart.getUser().getFullName())
                    .address(shoppingCart.getUser().getAddress())
                    .isShoppingCart(false)
                    .build();
            order.setCreatedAt(LocalDateTime.now());
            orderRepository.save(order);
            orderDetailRepository.saveAll(orderDetailSet);
            cartItemRepository.deleteAllByShoppingCartId(id);
            return order;
        }
        return null;
    }

    public int total(){
        return orderRepository.findAll().size();
    }

    public int totalByStatus(int status){
        OrderStatus status1 = null;
        if (status == 0){
            status1 = OrderStatus.PENDING;
        }if (status == 1){
            status1 = OrderStatus.CONFIRMED;
        }if (status == 2){
            status1 = OrderStatus.CANCELLED;
        }
        if (status == 3){
            status1 = OrderStatus.DONE;
        }
        return orderRepository.findAllByStatus(status1).size();
    }

    public BigDecimal profit(){
        List<Order> orderList = orderRepository.findAllByStatus(OrderStatus.DONE);
        BigDecimal profit = BigDecimal.valueOf(0);
        for (Order order:orderList
             ) {
            profit = profit.add(order.getTotalPrice());
        }
        return profit;
    }

    public BigDecimal profitByTime(String start, String end){
        LocalDateTime startTime = LocalDateTime.parse(start);
        LocalDateTime endTime = LocalDateTime.parse(end);

        List<Order> orderList = orderRepository. findAllByStatusAndCreatedAtBetween(OrderStatus.DONE, startTime, endTime);
        BigDecimal profit = BigDecimal.valueOf(0);
        for (Order order:orderList
        ) {
            profit = profit.add(order.getTotalPrice());
        }
        return profit;
    }
}
