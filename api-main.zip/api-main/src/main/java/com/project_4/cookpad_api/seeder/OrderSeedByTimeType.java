package com.project_4.cookpad_api.seeder;

public enum OrderSeedByTimeType {
    DAY, MONTH, YEAR
}
