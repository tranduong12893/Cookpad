package com.project_4.cookpad_api.service;

import com.project_4.cookpad_api.entity.Role;
import com.project_4.cookpad_api.entity.User;
import com.project_4.cookpad_api.entity.dto.CredentialDto;
import com.project_4.cookpad_api.entity.dto.RegisterDto;
import com.project_4.cookpad_api.entity.myenum.Status;
import com.project_4.cookpad_api.repository.RoleRepository;
import com.project_4.cookpad_api.repository.UserRepository;
import com.project_4.cookpad_api.search.UserSpecification;
import com.project_4.cookpad_api.search.SearchBody;
import com.project_4.cookpad_api.search.SearchCriteria;
import com.project_4.cookpad_api.util.ConvertDateHelper;
import com.project_4.cookpad_api.util.JWTUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.*;

import static com.project_4.cookpad_api.search.SearchCriteriaOperator.*;

@Service
@Transactional
@RequiredArgsConstructor
public class UserService implements UserDetailsService {
    @Autowired
    UserRepository userRepository;

    @Autowired
    RoleRepository roleRepository;

    final PasswordEncoder passwordEncoder;

    public boolean matchPassword(String rawPassword, String hashPassword){
        return passwordEncoder.matches(rawPassword, hashPassword);
    }

    public String encodePassword(String rawPassword){
        return passwordEncoder.encode(rawPassword);
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<User> userOptional = userRepository.findByUsernameAndStatus(username, Status.ACTIVE);
        User user = userOptional.orElse(null);
        if (user == null){
            throw new UsernameNotFoundException("User not found");
        }
        Collection<SimpleGrantedAuthority> authorities = new ArrayList<>();
        SimpleGrantedAuthority authority = new SimpleGrantedAuthority(user.getRole().getName());
        authorities.add(authority);
        return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), authorities);
    }

    public CredentialDto generateCredential(UserDetails userDetail, HttpServletRequest request) {
        String accessToken = JWTUtil.generateToken(userDetail.getUsername(),
                userDetail.getAuthorities().iterator().next().getAuthority(),
                request.getRequestURI(),
                JWTUtil.ONE_DAY * 7);

        String refreshToken = JWTUtil.generateToken(userDetail.getUsername(),
                userDetail.getAuthorities().iterator().next().getAuthority(),
                request.getRequestURI(),
                JWTUtil.ONE_DAY * 14);
        return new CredentialDto(accessToken, refreshToken);
    }

    public User register(RegisterDto registerDto){
        Role role = roleRepository.findByName("USER");
        User user = User.builder()
                .username(registerDto.getUsername())
                .password(passwordEncoder.encode(registerDto.getPassword()))
                .fullName(registerDto.getFullName())
                .address(null)
                .phone(null)
                .email(null)
                .detail(null)
                .avatar("https://images.squarespace-cdn.com/content/v1/54b7b93ce4b0a3e130d5d232/1519987020970-8IQ7F6Z61LLBCX85A65S/icon.png?format=1000w")
                .followNumber(0)
                .role(role)
                .status(Status.ACTIVE)
                .build();
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());
        user.setCreatedBy(registerDto.getFullName());
        user.setUpdatedBy(registerDto.getFullName());
        return userRepository.save(user);
    }


    public Optional<User> findByNameActive(String username){
        return userRepository.findByUsernameAndStatus(username, Status.ACTIVE);
    }

    public Optional<User> findByIdActive(Long id){
        return userRepository.findByIdAndStatus(id, Status.ACTIVE);
    }

    public Map<String, Object> findAll(SearchBody searchBody){
        Specification specification = Specification.where(null);

        if (searchBody.getGender() != null && searchBody.getGender().length() > 0 ){
            specification = specification.and(new UserSpecification(new SearchCriteria("gender", EQUALS, searchBody.getGender())));
        }
        if (searchBody.getRoleId() > 0){
            specification = specification.and(new UserSpecification(new SearchCriteria("role", EQUALS, searchBody.getRoleId())));
        }
        if (searchBody.getStatus() > -1){
            specification = specification.and(new UserSpecification(new SearchCriteria("status", EQUALS, searchBody.getStatus())));
        }
        if (searchBody.getUsername() != null && searchBody.getUsername().length() > 0 ){
            specification = specification.and(new UserSpecification(new SearchCriteria("username", LIKE, "%" + searchBody.getUsername() + "%")));
        }
        if (searchBody.getFullName() != null && searchBody.getFullName().length() > 0 ){
            specification = specification.and(new UserSpecification(new SearchCriteria("fullName", LIKE, "%" + searchBody.getFullName() + "%")));
        }
        if (searchBody.getEmail() != null && searchBody.getEmail().length() > 0 ){
            specification = specification.and(new UserSpecification(new SearchCriteria("email", LIKE, "%" + searchBody.getEmail() + "%")));
        }
        if (searchBody.getPhone() != null && searchBody.getPhone().length() > 0){
            specification = specification.and(new UserSpecification(new SearchCriteria("phone",LIKE, "%" + searchBody.getPhone() + "%")));
        }
        if (searchBody.getStart() != null && searchBody.getStart().length() > 0){
//            log.info("check start: " + orderSearchBody.getStart() );
//            log.info("Check Start begin" + searchBody.getStart());

            LocalDateTime date = ConvertDateHelper.convertStringToLocalDateTime(searchBody.getStart());
//            log.info("Check Start" + date);
//            log.info("check start convert date: " + date );
            specification = specification.and(new UserSpecification(new SearchCriteria("createdAt", GREATER_THAN_OR_EQUALS,date)));
        }
        if (searchBody.getEnd() != null && searchBody.getEnd().length() > 0){
            LocalDateTime date = ConvertDateHelper.convertStringToLocalDateTime(searchBody.getEnd());
            specification = specification.and(new UserSpecification(new SearchCriteria("createdAt", LESS_THAN_OR_EQUALS,date)));
        }

        Sort sort= Sort.by(Sort.Order.asc("createdAt"));
        if (searchBody.getSort() !=null && searchBody.getSort().length() >0){
            if (searchBody.getSort().contains("desc")){
                sort = Sort.by(Sort.Order.desc("createdAt"));
            }
        }
        Pageable pageable = PageRequest.of(searchBody.getPage() -1, searchBody.getLimit(),sort );
        Page<User> pageUser = userRepository.findAll(specification,pageable);
        List<User> orderList = pageUser.getContent();
        Map<String, Object> responses = new HashMap<>();
        responses.put("content",orderList);
        responses.put("currentPage",pageUser.getNumber() + 1);
        responses.put("totalItems",pageUser.getTotalElements());
        responses.put("totalPage",pageUser.getTotalPages());
        return responses;
    }

    public Optional<User> findById(Long id){
        return userRepository.findById(id);
    }

    public User save(User user){
        return userRepository.save(user);
    }

    public void deleteById(Long id){
        userRepository.deleteById(id);
    }

    public Optional<User> findByUsername(String username){
        return userRepository.findByUsername(username);
    }

    public Optional<User> findByEmail(String email){
        return userRepository.findByEmail(email);
    }

    public Optional<User> findByPhone(String phone){
        return userRepository.findByPhone(phone);
    }

    public int totalUser(){
        return userRepository.findAll().size();
    }

    public int totalUserByStatus(int status){
        Status status1 = Status.ACTIVE;
        if (status == 0){
            status1 = Status.INACTIVE;
        }if (status == 2){
            status1 = Status.UNDEFINED;
        }
        return userRepository.findAllByStatus(status1).size();
    }

    public int totalUserByRole(Long roleId){
        Optional<Role> role = roleRepository.findById(roleId);
        return userRepository.findAllByRole(role.get()).size();
    }
}
