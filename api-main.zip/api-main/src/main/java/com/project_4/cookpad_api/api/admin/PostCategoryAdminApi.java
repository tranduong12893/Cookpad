package com.project_4.cookpad_api.api.admin;

import com.project_4.cookpad_api.entity.Category;
import com.project_4.cookpad_api.entity.PostCategory;
import com.project_4.cookpad_api.service.CategoryService;
import com.project_4.cookpad_api.service.PostCategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(path = "api/v1/admin/postCategories")
@RequiredArgsConstructor
@CrossOrigin("*")
public class PostCategoryAdminApi {
    @Autowired
    PostCategoryService postCategoryService;

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<PostCategory>> findAll(){
        return ResponseEntity.ok(postCategoryService.findAll());
    }
}
