package com.project_4.cookpad_api.api.client;

import com.project_4.cookpad_api.entity.Order;
import com.project_4.cookpad_api.entity.ShoppingCart;
import com.project_4.cookpad_api.entity.User;
import com.project_4.cookpad_api.entity.event.OrderEvent;
import com.project_4.cookpad_api.repository.ShoppingCartRepository;
import com.project_4.cookpad_api.service.IOrderService;
import com.project_4.cookpad_api.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import java.security.Principal;
import java.util.Optional;

@CrossOrigin("*")
@RestController
@RequestMapping(path = "api/v1/orders")
public class OrderApi {
    @Autowired
    UserService userService;
    @Autowired
    ShoppingCartRepository shoppingCartRepository;

    private final IOrderService iOrderService;

    public OrderApi(IOrderService iOrderService) {
        this.iOrderService = iOrderService;
    }


    @RolesAllowed("USER")
    @RequestMapping(method = RequestMethod.POST, path = "/checkout")
    public ResponseEntity<?> placeOrder(@RequestParam long shoppingCartId, Principal principal) {
        User user = userService.findByUsername(principal.getName()).get();
        Optional<ShoppingCart> optionalShoppingCart = shoppingCartRepository.findByUserId(user.getId());
        if (optionalShoppingCart.isPresent()) {
            if (shoppingCartId > 0) {
                Order result = iOrderService.placeOrder(shoppingCartId);
                if (result != null) {
                    return ResponseEntity.ok(result);
                } else {
                    return ResponseEntity.notFound().build();
                }
            } else {
                return ResponseEntity.badRequest().build();
            }
        }
        return ResponseEntity.notFound().build();
    }
}
