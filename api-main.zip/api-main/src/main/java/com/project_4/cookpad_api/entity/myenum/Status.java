package com.project_4.cookpad_api.entity.myenum;

public enum Status {
    INACTIVE, ACTIVE, UNDEFINED, AVAILABLE, PENDING, LOCKED, SOLDOUT
}
