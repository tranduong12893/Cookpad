package com.project_4.cookpad_api.repository;

import com.project_4.cookpad_api.entity.OrderDetail;
import com.project_4.cookpad_api.entity.OrderDetailId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderDetailRepository extends JpaRepository<OrderDetail, OrderDetailId> {

}
