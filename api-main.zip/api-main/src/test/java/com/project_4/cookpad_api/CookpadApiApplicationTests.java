package com.project_4.cookpad_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CookpadApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
